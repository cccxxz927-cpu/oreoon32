// supabase-config.js
const SUPABASE_CONFIG = {
    url: 'https://your-project.supabase.co',  // 🔴 استبدل برابط مشروعك
    key: 'your-anon-public-key',              // 🔴 استبدل بالمفتاح العام
    table: 'lectures'
};

// دالة مساعدة للاتصال
async function fetchFromSupabase(endpoint, options = {}) {
    const defaultHeaders = {
        'apikey': SUPABASE_CONFIG.key,
        'Authorization': `Bearer ${SUPABASE_CONFIG.key}`,
        'Content-Type': 'application/json'
    };

    const response = await fetch(`${SUPABASE_CONFIG.url}${endpoint}`, {
        ...options,
        headers: { ...defaultHeaders, ...options.headers }
    });

    if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
    return response.json();
}